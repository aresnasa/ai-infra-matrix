CurlShare() -> New CurlShare object

Creates a new :ref:`curlshareobject` which corresponds to a
``CURLSH`` handle in libcurl. CurlShare objects is what you pass as an
argument to the SHARE option on :ref:`Curl objects <curlobject>`.
