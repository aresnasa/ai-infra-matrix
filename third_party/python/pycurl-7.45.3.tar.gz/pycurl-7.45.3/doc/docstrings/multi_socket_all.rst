socket_all() -> tuple

Returns result from doing a socket_all() on the curl multi file descriptor
with the given timeout.
